export async function prepareImageUpload(file: File) {
    if (!file.type.startsWith('image/')) {
        return { file, contentType: file.type, originalName: file.name };
    }

    const maxSide = 1600;
    const dataUrl = await new Promise<string>((resolve, reject) => {
        const reader = new FileReader();
        reader.onload = () => resolve(String(reader.result || ''));
        reader.onerror = () => reject(new Error('Could not read image'));
        reader.readAsDataURL(file);
    });

    const image = await new Promise<HTMLImageElement>((resolve, reject) => {
        const element = new Image();
        element.onload = () => resolve(element);
        element.onerror = () => reject(new Error('Could not decode image'));
        element.src = dataUrl;
    });

    const sourceWidth = image.naturalWidth || image.width;
    const sourceHeight = image.naturalHeight || image.height;
    const scale = Math.min(1, maxSide / Math.max(sourceWidth, sourceHeight));
    const width = Math.max(1, Math.round(sourceWidth * scale));
    const height = Math.max(1, Math.round(sourceHeight * scale));
    const canvas = document.createElement('canvas');
    canvas.width = width;
    canvas.height = height;
    const context = canvas.getContext('2d');
    if (!context) throw new Error('Image processing is unavailable');
    context.drawImage(image, 0, 0, width, height);

    const blob = await new Promise<Blob | null>((resolve) => {
        canvas.toBlob(resolve, 'image/jpeg', 0.82);
    });
    if (!blob) throw new Error('Could not prepare image');

    const base = file.name.replace(/\.[^.]+$/, '') || 'image';
    return {
        file: new File([blob], `${base}.jpg`, { type: 'image/jpeg', lastModified: Date.now() }),
        contentType: 'image/jpeg',
        originalName: file.name,
    };
}
