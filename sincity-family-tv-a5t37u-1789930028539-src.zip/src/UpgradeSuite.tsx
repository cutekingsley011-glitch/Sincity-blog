import { useEffect, useState } from 'react';
import { api } from '@appdeploy/client';

const postIdOf = (post: any) => String(post?.id ?? post?._id ?? post?.postId ?? post?.post_id ?? '').trim();
const shareUrlFor = (id: string) => 'https://sincityblog.com.ng/?post=' + encodeURIComponent(id);
const canonicalPost = (value: any) => { const id = postIdOf(value); return id ? { ...value, id } : value; };

export function PostReader({ post, member, onClose }: { post: any; member?: any; onClose: () => void }) {
  const [p, setP] = useState(post);
  const [text, setText] = useState('');
  const [comments, setComments] = useState<any[]>([]);
  const [liked, setLiked] = useState(() => { const id = postIdOf(post); return Boolean(id) && localStorage.getItem('sincity_liked_' + id) === '1'; });
  const [busy, setBusy] = useState(false); const [commentNotice, setCommentNotice] = useState('');
  const getMember = () => { if (member?.name) { try { const saved = localStorage.getItem('sincity_member'); const parsed = saved ? JSON.parse(saved) : null; return { ...parsed, ...member }; } catch { return member; } } try { const raw = localStorage.getItem('sincity_member'); return raw ? JSON.parse(raw) : null; } catch { return null; } }; const isMember = () => Boolean(getMember()?.name);

  useEffect(() => {
    let active = true;
    const id = postIdOf(post);
    if (!id) {
      setCommentNotice('This story is missing its ID. Please refresh the newsroom.');
      return () => { active = false; };
    }
    const loadReader = async () => {
      const [postResult, commentResult] = await Promise.allSettled([
        api.get('/api/posts/' + encodeURIComponent(id), { headers: { 'Cache-Control': 'no-cache' } }),
        api.get('/api/posts/' + encodeURIComponent(id) + '/comments', { headers: { 'Cache-Control': 'no-cache' } }),
      ]);
      if (!active) return;
      if (postResult.status === 'fulfilled') {
        const fresh = canonicalPost(postResult.value.data);
        if (postIdOf(fresh)) setP(fresh);
        else setCommentNotice('The newsroom returned this story without a valid ID. Please refresh the newsroom.');
      }
      if (commentResult.status === 'fulfilled') setComments(Array.isArray(commentResult.value.data?.items) ? commentResult.value.data.items : []);
      if (postResult.status === 'rejected' && commentResult.status === 'rejected') setCommentNotice('We could not load this story. Please refresh the newsroom.');
    };
    void loadReader();
    return () => { active = false; };
  }, [post]);

  const like = async () => {
    const storyId = postIdOf(p) || postIdOf(post); if (!storyId) { alert('This story is missing its ID. Please refresh the newsroom.'); return; }
    if (liked || busy) return;
    const member = getMember();
    if (!member?.name) { window.dispatchEvent(new CustomEvent('sincity:join-required')); return; }
    setBusy(true);
    try {
      const r = await api.post('/api/posts/' + encodeURIComponent(storyId) + '/like', { memberId: member.id || '', memberToken: member.token || '', memberName: member.name || '' });
      setP((prev: any) => canonicalPost({ ...prev, likes: Number(r.data?.likes ?? (prev.likes || 0) + 1) }));
      setLiked(true);
      localStorage.setItem('sincity_liked_' + storyId, '1');
      api.post('/api/track', { type: 'like', postId: storyId }).catch(() => {});
    } catch (e: any) {
      alert(String(e?.data?.error || e?.response?.data?.error || e?.message || 'We could not record your like. Please try again.'));
    } finally {
      setBusy(false);
    }
  };

  const share = async () => {
    const member = getMember();
    if (!member?.name) { window.dispatchEvent(new CustomEvent('sincity:join-required')); return; }
    const storyId = postIdOf(p) || postIdOf(post); if (!storyId) { alert('This story is missing its ID. Please refresh the newsroom.'); return; }
    const url = shareUrlFor(storyId);
    try {
      if (navigator.share) await navigator.share({ title: p.title, text: p.subtitle || 'Sincity Blog — Where every sin has a story.', url });
      else if (navigator.clipboard) { await navigator.clipboard.writeText(url); alert('Story link copied.'); }
      else window.prompt('Copy this story link', url);
      const r = await api.post('/api/posts/' + encodeURIComponent(storyId) + '/share', { memberId: member.id || '', memberToken: member.token || '', memberName: member.name || '' });
      setP((prev: any) => canonicalPost({ ...prev, shares: r.data?.shares ?? prev.shares }));
      api.post('/api/track', { type: 'share', postId: storyId }).catch(() => {});
    } catch {}
  };

  const comment = async () => {
    const body = text.trim();
    if (!body) { setCommentNotice('Write your comment first.'); return; }
    const currentMember = getMember();
    if (!currentMember?.name) { setCommentNotice('Your Sincity membership could not be found. Please join Sincity again.'); window.dispatchEvent(new CustomEvent('sincity:join-required')); return; }
    setBusy(true); setCommentNotice('Posting your comment...');
    const storyId = postIdOf(p) || postIdOf(post); if (!storyId) { setCommentNotice('This story is missing its ID. Please refresh the newsroom.'); setBusy(false); return; }
    try {
      const r = await api.post('/api/posts/' + encodeURIComponent(storyId) + '/comments', { body, memberId: currentMember.id || '', memberToken: currentMember.token || '', memberName: currentMember.name || '' });
      if (!r.data?.comment) throw new Error('The server did not confirm the comment.');
      setComments((prev) => [...prev, r.data.comment]);
      setText('');
      setP((prev: any) => canonicalPost({ ...prev, comments: Number(r.data?.comments ?? (prev.comments || 0) + 1) }));
      setCommentNotice('Comment posted.');
      api.post('/api/track', { type: 'comment', postId: storyId }).catch(() => {});
    } catch (e: any) {
      setCommentNotice(String(e?.data?.error || e?.response?.data?.error || e?.message || 'We could not post your comment. Please try again.'));
    } finally { setBusy(false); }
  };

  const date = new Date(p.publishedAt || p.createdAt || Date.now());
  const readerStoryId = postIdOf(p) || postIdOf(post);
  const dateText = Number.isNaN(date.getTime()) ? 'Just now' : date.toLocaleDateString(undefined, { day: 'numeric', month: 'long', year: 'numeric' });
  return <div className='reader-overlay' onClick={onClose}>
    <article className='reader' onClick={(e) => e.stopPropagation()}>
      <button className='reader-close' onClick={onClose} aria-label='Close story'>×</button>
      {p.images?.[0]?.url && <img className='reader-cover' src={p.images[0].url} alt={p.title} />}
      <div className='reader-kicker'>{p.breaking ? 'BREAKING SIN' : p.category || 'NEWS'}</div>
      <h1>{p.title}</h1>
      <div className='reader-byline-ui'><span className='reader-author-mark'>SB</span><div><span>Published by</span><b>{p.author || 'Sincity Editorial'}</b></div><time>{dateText}</time></div>
      {p.subtitle && <h3>{p.subtitle}</h3>}
      <div className='reader-body'>{String(p.body || '').split('\n').map((x: string, i: number) => <p key={i}>{x}</p>)}</div>
      <div className='reader-actions'><button className={liked ? 'liked' : ''} aria-label={liked ? 'Story liked' : 'Like story'} onClick={like} disabled={busy || liked}>♥ {liked ? 'Liked · +1' : p.likes || 0}</button><button aria-label='Share story' onClick={share}>↗ {p.shares || 0} Share</button><button aria-label='Copy story link' onClick={async () => { const storyId = postIdOf(p); if (!storyId) { alert('This story is missing its ID. Please refresh the newsroom.'); return; } const u = shareUrlFor(storyId); if (navigator.clipboard) { await navigator.clipboard.writeText(u); alert('Story link copied.'); } else window.prompt('Copy this story link', u); }}>Copy link</button></div>
      <section className='reader-comments'><div className='comments-head'><div><span className='eyebrow'>THE CONVERSATION</span><h3>{isMember() ? 'The conversation' : 'Join the conversation'}</h3></div><span>{comments.length || p.comments || 0}</span></div>{comments.length > 0 && <div className='comment-list'>{comments.map((c: any) => <div className='comment-item' key={c.id}><b>{c.name || 'Sincity Insider'}</b><p>{c.body || c.text}</p></div>)}</div>}<textarea value={text} onChange={(e) => setText(e.target.value)} placeholder={isMember() ? 'Write a comment...' : 'Join Sincity to comment'} /><button className='primary' onClick={comment}>{isMember() ? 'Post Comment' : 'Join Sincity'}</button></section>
    </article>
  </div>;
}

export function NotificationBell() { const [items, setItems] = useState<any[]>([]), [open, setOpen] = useState(false); useEffect(() => { api.get('/api/notifications').then(r => setItems(r.data.items || [])).catch(() => {}); }, []); return <div className='notify-wrap'><button className='notify-btn' onClick={() => setOpen(!open)}>♢<sup>{items.length || ''}</sup></button>{open && <div className='notify-pop'>{items.length ? items.map((n, i) => <div key={i}><b>{n.type || 'Notice'}</b><p>{n.message}</p><small>{new Date(n.createdAt).toLocaleString()}</small></div>) : <span>No notifications yet.</span>}</div>}</div>; }

export function AdvertisePage() { const [f, setF] = useState<any>({ name: '', business: '', contact: '', package: 'Sponsored Post', message: '' }), [msg, setMsg] = useState(''); useEffect(() => { if (!msg) return; const timer = window.setTimeout(() => setMsg(''), 3000); return () => window.clearTimeout(timer); }, [msg]); const submit = async () => { try { await api.post('/api/advertise', f); setMsg('Request submitted for review.'); setF({ name: '', business: '', contact: '', package: 'Sponsored Post', message: '' }); } catch { setMsg('Please complete the required fields.'); } }; return <section className='feature-page'><div className='premium-page'><span className='eyebrow'>SINCITY FOR BUSINESS</span><h1>Promote your business.</h1><p>Sponsored stories, banners and event promotions for the Sincity audience.</p><div className='ad-packages'><div><b>Sponsored Post</b><span>Story-style promotion</span></div><div><b>Banner</b><span>High visibility</span></div><div><b>Event Promotion</b><span>Drive attention</span></div></div><div className='ad-form'><input placeholder='Your name *' value={f.name} onChange={e => setF({...f,name:e.target.value})}/><input placeholder='Business / brand *' value={f.business} onChange={e => setF({...f,business:e.target.value})}/><input placeholder='WhatsApp / phone *' value={f.contact} onChange={e => setF({...f,contact:e.target.value})}/><select value={f.package} onChange={e => setF({...f,package:e.target.value})}><option>Sponsored Post</option><option>Banner</option><option>Event Promotion</option></select><textarea placeholder='What should we promote?' value={f.message} onChange={e => setF({...f,message:e.target.value})}/><button className='primary' onClick={submit}>Request Promotion</button>{msg&&<p>{msg}</p>}</div></div></section>; }

export function UpgradeAdmin({ session, onNotice }: { session: string; onNotice: (x: string) => void }) { const [tab, setTab] = useState('insights'), [a, setA] = useState<any>({}), [members, setMembers] = useState<any[]>([]), [ads, setAds] = useState<any[]>([]), [req, setReq] = useState<any[]>([]), [note, setNote] = useState(''); const load = async () => { const s = encodeURIComponent(session); const results = await Promise.allSettled([api.get('/api/admin/analytics-detailed?session=' + s), api.get('/api/admin/members?session=' + s), api.get('/api/admin/ads?session=' + s), api.get('/api/admin/ad-requests?session=' + s)]); const [x,m,d,r] = results; if (x.status === 'fulfilled') setA(x.value.data); if (m.status === 'fulfilled') setMembers(m.value.data.items || []); if (d.status === 'fulfilled') setAds(d.value.data.items || []); if (r.status === 'fulfilled') setReq(r.value.data.items || []); if ([x,m,d,r].some(v => v.status === 'rejected')) onNotice('Some Command Centre data could not load. Available sections remain active.'); }; useEffect(() => { load(); }, [session]); return <section className='panel upgrade-admin'><div className='upgrade-head'><div><span className='eyebrow'>PLATFORM SYSTEMS</span><h2>Command Centre</h2><p>Analytics, members, advertising, notifications and security.</p></div><div className='upgrade-tabs'>{['insights','members','advertising','notifications','security'].map(x => <button key={x} className={tab === x ? 'on' : ''} onClick={() => setTab(x)}>{x}</button>)}</div></div>{tab === 'insights' && <><div className='metrics'><div><b>{a.totalEvents || 0}</b><span>Total activity</span></div><div><b>{a.pageViews || 0}</b><span>Page views</span></div><div><b>{a.postViews || 0}</b><span>Post views</span></div><div><b>{a.engagements || 0}</b><span>Engagements</span></div><div><b>{a.searches || 0}</b><span>Searches</span></div><div><b>{a.uniqueDays || 0}</b><span>Active days</span></div></div><div className='activity-bars'>{Object.entries(a.byDay || {}).slice(-14).map(([d,v]: any) => <div key={d}><i style={{ height: Math.min(100, Math.max(8, Number(v) * 6)) + '%' }} /><span>{d.slice(5)}</span></div>)}</div></>}{tab === 'members' && members.map(m => <div className='adminrow' key={m.id}><div><b>{m.name}</b><small>{m.status || 'active'} · {m.joinedAt ? new Date(m.joinedAt).toLocaleString() : '—'}</small></div><button onClick={async () => { await api.put('/api/admin/members/' + m.id, { session, status: m.status === 'suspended' ? 'active' : 'suspended' }); load(); }}>{m.status === 'suspended' ? 'Restore' : 'Suspend'}</button></div>)}{tab === 'advertising' && <>{req.map(r => <div className='adminrow' key={r.id}><div><b>{r.business}</b><small>{r.name} · {r.contact} · {r.package}</small></div><button onClick={async () => { await api.put('/api/admin/ad-requests/' + r.id, { session, status: 'approved' }); load(); }}>Approve</button><button className='danger' onClick={async () => { await api.put('/api/admin/ad-requests/' + r.id, { session, status: 'rejected' }); load(); }}>Reject</button></div>)}{ads.map(x => <div className='adminrow' key={x.id}><div><b>{x.title || x.client}</b><small>{x.type} · {x.status}</small></div><button onClick={async () => { await api.put('/api/admin/ads/' + x.id, { session, status: x.status === 'active' ? 'paused' : 'active' }); load(); }}>{x.status === 'active' ? 'Pause' : 'Activate'}</button></div>)}</>}{tab === 'notifications' && <div className='notice-composer'><textarea value={note} onChange={e => setNote(e.target.value)} placeholder='Write an announcement...'/><button className='primary' onClick={async () => { if (!note.trim()) return; await api.post('/api/admin/notifications', { session, message: note, type: 'announcement' }); setNote(''); onNotice('Announcement published.'); }}>Publish Announcement</button></div>}{tab === 'security' && <div className='security-box'><b>Protected admin session</b><p>The password remains in AppDeploy Secrets. Successful login creates an 8-hour server-side session so the password is not repeatedly sent to admin APIs.</p></div>}</section>; }
