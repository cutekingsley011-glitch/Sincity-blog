import { useMemo } from 'react';

type Props = {
  posts: any[];
  cat?: string;
  setCat?: (value: string) => void;
  onOpen: (post: any) => void;
};

export default function EditorialExtras({ posts, cat, setCat, onOpen }: Props) {
  const trending = useMemo(
    () => [...posts]
      .map((post: any) => ({
        ...post,
        popularity: (Number(post.views) || 0) + (Number(post.likes) || 0) * 3 + (Number(post.comments) || 0) * 4 + (Number(post.shares) || 0) * 2,
      }))
      .sort((a: any, b: any) => b.popularity - a.popularity)
      .slice(0, 10),
    [posts],
  );

  return (
    <>
      <section className='home-section' aria-labelledby='trending-title'>
        <div className='sectiontitle'>
          <div>
            <span className='eyebrow'>TRENDING NOW</span>
            <h2 id='trending-title'>What the city is reading</h2>
          </div>
          <span>TOP 10 · BY ENGAGEMENT</span>
        </div>

        {trending.length ? (
          <div className='trend-list'>
            {trending.map((p: any, i: number) => (
              <article
                className='trend-item'
                key={p.id}
                tabIndex={0}
                role='button'
                aria-label={'Read ' + p.title}
                onClick={() => onOpen(p)}
                onKeyDown={(e) => {
                  if (e.key === 'Enter' || e.key === ' ') onOpen(p);
                }}
              >
                <b className='trend-rank'>{String(i + 1).padStart(2, '0')}</b>
                <div className='trend-copy'>
                  <span>{p.category}</span>
                  <h3>{p.title}</h3>
                  <small>{p.views || 0} views · {p.likes || 0} likes · {p.comments || 0} comments · {p.shares || 0} shares</small>
                </div>
                <span className='trend-arrow' aria-hidden='true'>↗</span>
              </article>
            ))}
          </div>
        ) : (
          <div className='empty-state'>
            <h3>Nothing is trending yet.</h3>
            <p>Fresh stories will appear here as readers engage.</p>
          </div>
        )}
      </section>
    </>
  );
}
