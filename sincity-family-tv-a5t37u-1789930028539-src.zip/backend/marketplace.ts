import { db, error, json, secrets, storage } from '@appdeploy/sdk';

const secret = async () => {
  try { return await secrets.readSecret('SINCITY_ADMIN_PASSWORD'); } catch { return ''; }
};
const now = () => new Date().toISOString();
const mediaUrl = (path: string) => '/api/media/' + encodeURIComponent(path);
async function freshMediaUrl(path: string) {
  try {
    const [{ url }] = await storage.url([path]);
    return url || mediaUrl(path);
  } catch {
    return mediaUrl(path);
  }
}
const rawBase64 = (value: string) => {
  const s = String(value || '');
  const comma = s.indexOf(',');
  return s.startsWith('data:') && comma >= 0 ? s.slice(comma + 1) : s;
};
async function findAdminSession(token: string) { let nextToken: string | undefined; for (let page = 0; page < 20; page++) { const result = await db.list<{ token: string; expiresAt: number }>('admin_sessions', { limit: 100, nextToken }); const found = result.items.find((item) => item.token === token); if (found) return found; if (!result.nextToken) break; nextToken = result.nextToken; } return null; } /* legacy session lookup body retained below */
async function _legacyFindAdminSession(token: string) {
  const { items } = await db.list<{ token: string; expiresAt: number }>('admin_sessions', { limit: 100 });
  return items.find((item) => item.token === token) || null;
}
async function adminAuth(body: any) {
  if (body?.session) {
    const session = await findAdminSession(String(body.session));
    if (session && Number(session.expiresAt) > Date.now()) return true;
  }
  return !!body?.password && body.password === (await secret());
}
export const marketplaceRoutes = {
  'POST /api/marketplace/upload': [async ({ body }) => {
    const b: any = body;
    const [member] = b.memberId ? await db.get<any>('members', [String(b.memberId)]) : [null];
    if (!member || member.status === 'banned' || member.status === 'suspended' || String(member.token || '') !== String(b.memberToken || '')) return error('Your Sincity membership could not be verified. Please join Sincity again.', 401);
    if (!b.data || !String(b.type || '').startsWith('image/')) return error('Valid product image required', 400);
    if (Number(b.size) > 8 * 1024 * 1024) return error('Image exceeds the 8 MB limit', 400);
    const safe = String(b.name || 'product').replace(/[^a-zA-Z0-9._-]/g, '_');
    const path = 'marketplace/' + Date.now() + '-' + Math.random().toString(36).slice(2, 9) + '-' + safe;
    const encoded = rawBase64(String(b.data));
    if (!encoded) return error('Valid product image required', 400);
    try {
      const [ok] = await storage.write([{ path, content: encoded, contentType: String(b.type) }]);
      if (!ok) return error('Photo upload failed. Please choose the photo again and retry.', 500);
      return json({ image: { path, url: mediaUrl(path), name: safe, size: Number(b.size), type: b.type } });
    } catch (e) {
      console.error('Marketplace photo upload failed', e);
      return error('Photo upload failed. Please try again.', 500);
    }
  }],
  'GET /api/marketplace': [async () => {
    const { items } = await db.list<any>('marketplace', { limit: 100 });
    const publicItems = await Promise.all(items.filter((x) => ['active', 'approved', 'published', 'sold'].includes(String(x.status || '').toLowerCase())).map(async (x) => {
      const rawStatus = String(x.status || '').toLowerCase();
      const normalized = { ...x, status: rawStatus === 'sold' ? 'sold' : 'active' };
      return x.image?.path ? { ...normalized, image: { ...x.image, url: await freshMediaUrl(String(x.image.path)) } } : normalized;
    }));
    return json({ items: publicItems.sort((a: any, b: any) => String(b.createdAt || '').localeCompare(String(a.createdAt || ''))) });
  }],
  'POST /api/marketplace': [async ({ body }) => {
    const b: any = body;
    const [member] = b.memberId ? await db.get<any>('members', [String(b.memberId)]) : [null];
    if (!member || member.status === 'banned' || member.status === 'suspended' || String(member.token || '') !== String(b.memberToken || '')) return error('Your Sincity membership could not be verified. Please join Sincity again.', 401);
    if (!b.title?.trim() || !b.description?.trim() || !Number(b.price) || Number(b.price) <= 0 || !member.name?.trim() || !b.contact?.trim() || !b.image?.path) return error('Required marketplace fields are missing', 400);
    const imagePath = String(b.image.path);
    if (!imagePath.startsWith('marketplace/') || imagePath.includes('..')) return error('Invalid product photo', 400);
    try {
      const [id] = await db.add('marketplace', [{ title: b.title.trim(), description: b.description.trim(), reason: String(b.reason || '').trim(), price: Number(b.price), sellerName: String(member.name).trim(), contact: b.contact.trim(), image: { ...b.image, path: imagePath, url: mediaUrl(imagePath) }, status: 'pending', createdAt: now(), updatedAt: now() }]);
      if (!id) return error('Could not submit marketplace listing. Please try again.', 500);
      return json({ ok: true, id, status: 'pending' });
    } catch (e) {
      console.error('Marketplace listing submission failed', e);
      return error('Could not submit the listing. Please try again.', 500);
    }
  }],
  'GET /api/admin/marketplace': [async ({ query }) => {
    if (!(await adminAuth(query))) return error('Unauthorized', 401);
    const { items } = await db.list<any>('marketplace', { limit: 100 });
    const normalized = await Promise.all(items.map(async (x) => x.image?.path ? { ...x, image: { ...x.image, url: await freshMediaUrl(String(x.image.path)) } } : x));
    return json({ items: normalized.sort((a, b) => String(b.createdAt || '').localeCompare(String(a.createdAt || ''))) });
  }],
  'PUT /api/admin/marketplace/:id': [async ({ params, body }) => {
    if (!(await adminAuth(body))) return error('Unauthorized', 401);
    const allowed = ['active', 'declined', 'sold', 'deleted'];
    const status = String((body as any).status || '');
    if (!allowed.includes(status)) return error('Invalid marketplace status', 400);
    const [x] = await db.get<any>('marketplace', [params.id]);
    if (!x) return error('Listing not found', 404);
    if (status === 'deleted') {
      if (x.image?.path) await storage.delete([String(x.image.path)]);
      const [ok] = await db.delete('marketplace', [params.id]);
      return json({ ok });
    }
    const [ok] = await db.update('marketplace', [{ id: params.id, record: { ...x, status, updatedAt: now() } }]);
    return json({ ok });
  }],
};
