import { db, json, error } from '@appdeploy/sdk';
import { notifySubscribers } from './realtime-subscribers';

type PostRecord = { title: string; excerpt: string; category: string; image: string; likes: number; comments: number; featured?: boolean };
type CommentRecord = { post_id: string; name: string; text: string };

export const contentRoutes = {
  'GET /api/posts': [async () => {
    const { items } = await db.list<PostRecord>('posts', { limit: 30 });
    return json({ items });
  }],
  'POST /api/posts': [async ({ body }) => {
    const p = body as PostRecord;
    if (!p?.title || !p?.excerpt) return error('title and excerpt are required', 400);
    const [id] = await db.add('posts', [{ ...p, likes: 0, comments: 0 }]);
    if (!id) return error('Could not create post', 500);
    return json({ item: { id, ...p, likes: 0, comments: 0 } });
  }],
  'POST /api/posts/:id/like': [async ({ params }) => {
    const [p] = await db.get<PostRecord>('posts', [params.id]);
    if (!p) return error('Post not found', 404);
    const next = { ...p, likes: (p.likes || 0) + 1 };
    const [ok] = await db.update('posts', [{ id: params.id, record: next as Record<string, unknown> }]);
    if (!ok) return error('Could not like post', 500);
    await notifySubscribers('post', params.id, { id: params.id, ...next });
    return json({ item: { id: params.id, ...next } });
  }],
  'GET /api/comments': [async ({ query }) => {
    if (!query.post_id) return error('post_id is required', 400);
    const { items } = await db.list<CommentRecord>('comments', { limit: 50, filter: { post_id: query.post_id } });
    return json({ items });
  }],
  'POST /api/comments': [async ({ body }) => {
    const c = body as CommentRecord;
    if (!c?.post_id || !c?.text) return error('post_id and text are required', 400);
    const [id] = await db.add('comments', [{ post_id: c.post_id, name: c.name || 'Sincity Insider', text: c.text }]);
    if (!id) return error('Could not add comment', 500);
    const [p] = await db.get<PostRecord>('posts', [c.post_id]);
    if (p) {
      const next = { ...p, comments: (p.comments || 0) + 1 };
      await db.update('posts', [{ id: c.post_id, record: next as Record<string, unknown> }]);
      await notifySubscribers('post', c.post_id, { id: c.post_id, ...next });
    }
    return json({ item: { id, post_id: c.post_id, name: c.name || 'Sincity Insider', text: c.text } });
  }]
};